function Gauss_por_pivotamento_parcial

A = (matriz);
M = (matriz);
B = (vetor);
A=[A';B']';     %pega a matriz e o vetor e transforma em uma unica matriz
n = size(A,1);   %numero de linhas da matriz

clc;
    
disp('-----------------------------------------------');
disp('---   ELIMINA��O DE GAUSS POR PIVOTAMENTO   ---');
disp('-----------------------------------------------');


disp('A:');disp(M);
disp('B:');disp(B);
disp('Matriz A|B: ');disp(A);
disp('  ---------------------------------------------');
disp('  ---            Resultado final            ---');
disp('  ---------------------------------------------');
disp('  ---              Vetor C:                 ---');
for etapa = 1 : n -1    %alternando as linhas caso precise 
        
    pivot = A(etapa,etapa);           
    
    for i = etapa + 1 : n
        if abs(A(i,etapa)) > abs(pivot)                 
            linha_pivotamento=i;               
            pivot = A(i, etapa);                    %ordenando a matriz
            aux = A(etapa, :);      
            A(etapa,:) = A(linha_pivotamento,:);                        
            A(linha_pivotamento,:) = aux;             
        end
    end                                
      
    for i = etapa+1:n          %metodo para zerar os elementos
        c = A(i,etapa)/pivot;    %dividindo o pivot pelo proximo elemento para poder zerar
        disp(A(i,etapa));
        for j = 1 : n + 1               
            A(i,j) = A(i,j) - c*A(etapa,j);                         
        end            
    end               	
end
    
disp('  -----------------------------------------------');
disp('  ---            MATRIZ ESCALONADA            ---');
disp('  -----------------------------------------------');
disp(A);
aux = 0  ;
r(1,n) = A(n,n+1)/A(n,n);

for i = n - 1: -1 : 1   
    for k = n : -1 : 1      
        aux = aux + r(1,k) * A(i,k);           
    end 
    r(1,i) = (A(i,n+1) - aux) /A(i,i);
    aux = 0;        
end

disp('  -----------------------------------------------');
disp('  ---            Vetor X:                     ---');
disp('  -----------------------------------------------');
disp(r);
disp('  -----------------------------------------------');
disp('  ---        DETERMINANTE DA MATRIZ A:        ---');
disp('  -----------------------------------------------');

disp(det(M))
if (r(1) && r(2)&& r(3)) ~= 0
    disp('Consistente e determinado');
else
    disp('Consistente e indeterminado');
end

%%% SUBMENU PARA VOLTAR OU SAIR %%%

disp(' ');
disp(' ');
disp('-----------------------------------------------');
disp('----  1) MENU PRINCIPAL                   -----');
disp('----  2) SAIR                             -----');
disp('-----------------------------------------------');

valor = input('Digite aqui: ');

switch valor
    
    case 1
        Menu_Principal;
    case 2
        disp('Fim do programa')
    otherwise
        disp('-----------------------------------------------');
        disp(' Valor nao registrado, favor digitar novamente.');
        disp('-----------------------------------------------');
        disp(' ');
end