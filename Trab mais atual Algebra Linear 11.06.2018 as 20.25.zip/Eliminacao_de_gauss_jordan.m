function Eliminacao_de_gauss_jordan

A=matriz;
M=A;
B=vetor;
A=[A';B']';
[m,n]=size(A); %numero de linhas e colunas
clc

disp('-----------------------------------------------');
disp('---       ELIMINA��O DE GAUSS JORDAN        ---');
disp('-----------------------------------------------');


disp('A: ');disp(M);
disp('B: ');disp(B);
disp('A|B: ');disp(A);

disp(' ');
disp('-----------------------------------------------');
disp('---               RELAT�RIO                 ---');
disp('-----------------------------------------------');
disp('---                Vetor C:                 ---');
disp('-----------------------------------------------');    
for j=1:m-1     
    for z=2:m
        if A(j,j)==0
            t=A(1,:);A(1,:)=A(z,:);     %pivout
            A(z,:)=t;
        end
    end        
    for i=j+1:m     
        A(i,:)=A(i,:)-A(j,:)*(A(i,j)/A(j,j));   %converte os elementos a baixo da diagonal para zeros  
        disp(j);
    end
end
for j=m:-1:2        
    for i=j-1:-1:1
        A(i,:)=A(i,:)-A(j,:)*(A(i,j)/A(j,j));   %converte os elementos acima da diagonal para zeros
        disp(j);
    end
end
for s=1:m
    A(s,:)=A(s,:)/A(s,s);       %converte os elementos da diagonal principal para 1
    x(s)=A(s,n);
end
disp('-----------------------------------------------');
disp('---             MATRIZ ESCALONADA           ---');
disp('-----------------------------------------------');
disp('Matriz A|B: ');disp(A);
disp('-----------------------------------------------');
disp('---            Vetor X:                     ---');
disp('-----------------------------------------------');
disp(x')
disp('-----------------------------------------------');
disp('---        DETERMINANTE DA MATRIZ A:        ---');
disp('-----------------------------------------------');
disp(det(M));     %mostra o valor do determinante da matriz A
if (x(1) && x(2)&& x(3)) ~= 0
    disp('Consistente e determinado');
else
    disp('Consistente e indeterminado');
end
%%% SUBMENU PARA VOLTAR OU SAIR %%%

disp(' ');
disp(' ');
disp('-----------------------------------------------');
disp('----  1) MENU PRINCIPAL                   -----');
disp('----  2) SAIR                             -----');
disp('-----------------------------------------------');

valor = input('Digite aqui: ');

switch valor
    
    case 1
        Menu_Principal;
    case 2
        disp('Fim do programa');
    otherwise
        disp('-----------------------------------------------');
        disp(' Valor nao registrado, favor digitar novamente.');
        disp('-----------------------------------------------');
        disp(' ');
end