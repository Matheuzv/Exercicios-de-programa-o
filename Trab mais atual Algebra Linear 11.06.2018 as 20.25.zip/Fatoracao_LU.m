
A=matriz;    %variavel A recebe o valor da matriz do arquivo matriz.m
B=vetor;
matrizA = A;
[m,n]=size(A);
L = eye(n); P=L; U=A;

clc     %apaga informa��es anteriores na tela

disp('-----------------------------------------------');
disp('----             Fatora��o LU              ----');
disp('-----------------------------------------------');
disp(' ');

if m~=n, error('Matriz A precisa ser quadrada'); end

disp('A= ');disp(A)

M=[L;U]';

disp('-----------------------------------------------');

for k=1:n
    [pivot m] = max (abs(U(k:n,k)));
    m = m+k-1;
    if m~=k         
                        %troca as linhas m e k da matriz U
        aux=U(k,:);
        U(k,:)=U(m,:);
        U(m,:)=aux;     
        aux=P(k,:);
                         %troca as linhas m e k da matriz P
        P(k,:);
        P(m,:)=aux;
        M=[L';U']';
       
        if k >= 2
            aux=L (k,1:k-1);
            L(k,1:k-1)=L(m,1:k-1);
            L(m,1:k-1)=aux;
            M=[L';U']';       
        end        
        M=[L';U']';    
    end
    for j=k+1:n
        L(j,k)=U(j,k)/U(k,k);
        U(j,:)=U(j,:)-L(j,k)*U(k,:);
        M=[L';U']';
    end
end
disp('Relat�rio');disp(' ');
disp('L = '); disp(L);
disp('U = '); disp(U);

Pb = P*B;
d = L\Pb;
x = U\d;
disp('-----------------------------------------------');
disp('---            Vetor X:                     ---');
disp('-----------------------------------------------');
disp('x = ');disp(x);
detr = det(matrizA);

disp('Determinante da matriz �:');
disp(detr);     %mostra o determinante da matriz A
if (x(1) && x(2)&& x(3)) ~= 0
    disp('Consistente e determinado');
else
    disp('Consistente e indeterminado');
end
    


%%% SUBMENU PARA VOLTAR OU SAIR %%%

disp(' ');
disp(' ');
disp('-----------------------------------------------');
disp('----  1) MENU PRINCIPAL                     ---');
disp('----  2) SAIR                               ---');
disp('-----------------------------------------------');

valor = input('Digite aqui: ');

switch valor
    
    case 1
        Menu_Principal;
    case 2
       disp('Fim do programa')
    otherwise
        disp('-----------------------------------------------');
        disp(' Valor nao registrado, favor digitar novamente.');
        disp('-----------------------------------------------');
        disp(' ');
        
end
        