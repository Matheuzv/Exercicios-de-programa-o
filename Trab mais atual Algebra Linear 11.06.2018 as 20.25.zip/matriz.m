function A=A
A =[4 5 6 ; 5 4 9 ;5 6 4 ];
end