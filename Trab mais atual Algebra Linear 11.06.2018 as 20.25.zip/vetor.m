function B=B
B =[8;2;3]
end