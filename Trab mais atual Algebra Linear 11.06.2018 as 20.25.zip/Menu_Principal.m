function Menu_Principal
clc
disp('-----------------------------------------------');
disp('-----------------------------------------------');
disp('---       TRABALHO DE ALGEBRA LINEAR        ---');
disp('-----------------------------------------------');
disp('-----------------------------------------------');
disp('---                                         ---');
disp('---           ESCOLHA UMA FUN��O:           ---');
disp('---                                         ---');
disp('--- 1) FATORA��O LU                         ---');
disp('--- 2) ELIMINA��O DE GAUSS                  ---');
disp('--- 3) ELIMINA��O DE GAUSS POR PIVOTAMENTO  ---');
disp('--- 4) ELIMINA��O DE GAUSS JORDAN           ---');
disp('--- 5) EQUIPE DESENVOLVEDORA e SAIR         ---');
disp('---                                         ---');
disp('-----------------------------------------------');
disp('-----------------------------------------------');
disp(' ');
MenuPrincipal;

function MenuPrincipal


N = input('Digite aqui: ');    %selecionar a opicao do menu


switch N
    
    case 1
        Fatoracao_LU;    %Fatora��o LU
    case 2
        Eliminacao_Gauss;     %Elimina��o de Gauss por pivotamento
    case 3
        Gauss_por_pivotamento_parcial;     %Elimina��o de Gauss
    case 4
        Eliminacao_de_gauss_jordan;  %Eliminacao de gauss Jordan
    case 5
        
        disp('-----------------------------------------------');
        disp('---                 EQUIPE:                 ---');
        disp('---                                         ---');
        disp('---   MARIO EVANDRO DO NASCIMENTO JUNIOR    ---');
        disp('---   IAGO MAGALH�ES FERNANDES              ---');
        disp('---   PABLO JUAN GONZALES                   ---');
        disp('---   MATHEUS VIEIRA DE ARAUJO              ---');
        disp('-----------------------------------------------');
        disp('Fim do programa');
                
    otherwise
        disp('-----------------------------------------------');
        disp(' Valor nao registrado, favor digitar novamente.');
        disp('-----------------------------------------------');
        disp(' ');
        MenuPrincipal;
end