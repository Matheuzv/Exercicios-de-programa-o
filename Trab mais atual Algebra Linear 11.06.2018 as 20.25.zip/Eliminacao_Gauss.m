function Eliminacao_Gauss

M = matriz;   %recebe valor do arquivo Matriz.m
A = M;
B = vetor;   %recebe o valor do arquivo vetor.m
determinante=det(M);  %armazenar determinante de A
[n n]=size(M);   %numero de linhas e colunas da matriz
M=[M';B']';
x=zeros(n,1);

clc     %limpar informa��es anteriores

disp('-----------------------------------------------');
disp('---          ELIMINA��O DE GAUSS            ---');
disp('-----------------------------------------------');

disp('A: '),disp(A);disp('B: '),disp(B);     %informa na tela a matriz-A e o vetor-B
disp('A|B: '); disp(M);

disp('-----------------------------------------------');
disp(' ');
disp('---               RELAT�RIO                 ---');
disp('-----------------------------------------------');
disp('---                Vetor C:                 ---');
disp('-----------------------------------------------');
for p=1:n          
    for k=[1:p-1,p+1:n]            
        m=-M(k,p)/M(p,p);            
        M(k,:)= M(k,:)+m*M(p,:);        
        disp(p);
    end
end
disp('---            MATRIZ ESCALONADA:           ---');
disp('-----------------------------------------------');
disp(M);

x = M(:,n+1)./diag(M);    %Calcula o X de incognitas

disp('-----------------------------------------------');
disp('---            Vetor X:                     ---');
disp('-----------------------------------------------');
disp(x);
disp('-----------------------------------------------');
disp('---        DETERMINANTE DA MATRIZ A:        ---');
disp('-----------------------------------------------');
disp(determinante);     %mostra o valor do determinante da matriz A
if (x(1) && x(2)&& x(3)) ~= 0
    disp('Consistente e determinado');
else
    disp('Consistente e indeterminado');
end



%%% SUBMENU PARA VOLTAR OU SAIR %%%

disp(' ');
disp(' ');
disp('-----------------------------------------------');
disp('----  1) MENU PRINCIPAL                   -----');
disp('----  2) SAIR                             -----');
disp('-----------------------------------------------');

valor = input('Digite aqui: ');

switch valor    
    
    case 1
        Menu_Principal;
    case 2
        disp('Fim do programa')
    otherwise
        disp('-----------------------------------------------');
        disp(' Valor nao registrado, favor digitar novamente.');
        disp('-----------------------------------------------');
        disp(' ');    
    
end