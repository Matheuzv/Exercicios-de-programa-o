/*----------------------------------------------------------------------------*/
/* UECE – Bacharelado em Ciência da Computação                                */
/* Cadeira de Estruturas de dados II                                          */
/* Alunos: Matheus Vieira de Araújo                                           */
/*         Samuel Alcântara Fontenele Rocha                                   */
/*         Beatriz Bianca Moreira Vasconcelos                                 */
/*----------------------------------------------------------------------------*/

#include "libArvRN.h"
#include "libArvRN.c"
#include<stdio.h>
#include<stdlib.h>

/*----------------------------------------------------------------------------*/
/* Menu funçoes                                                               */
/*----------------------------------------------------------------------------*/
int arvRN_menu (void) {
    int f;
    printf("\n");
    printf("\n");
    printf ("+--------------------------------+\n");
    printf ("+       Arvore Rubro Negra       +\n");
    printf ("+--------------------------------+\n");
    printf ("1 - Inserir                       \n");
    printf ("2 - Remover                       \n");
    printf ("3 - Buscar                        \n");
    printf ("4 - Imprimir                      \n");
    printf ("5 - Esvaziar                      \n");
    printf ("0 - Sair                          \n");
    printf ("Digite o numero da funcao RN: ");
    scanf ("%d", &f);
    return f;
}
/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Menu Imprimir                                                              */
/*----------------------------------------------------------------------------*/
int arvRN_menuImprimir (void) {
    int f;
    printf("\n");
    printf("\n");
    printf ("+--------------------------------+\n");
    printf ("+            Imprimir            +\n");
    printf ("+       Arvore Rubro Negra       +\n");
    printf ("+--------------------------------+\n");
    printf ("1 - Pre-ordem                     \n");
    printf ("2 - Em ordem                      \n");
    printf ("3 - Pos-ordem                     \n");
    printf ("4 - Voltar                        \n");
    printf ("Digite o numero da funcao RN: ");
    scanf ("%d", &f);
    return f;
}
/*----------------------------------------------------------------------------*/

void main () {
    int op, chave;
    Apontador aux;

    arvRN_inicializa();
    op = arvRN_menu ();
    while (op != 0) {
        switch (op) {
            case 1: //Inserir
                printf ("Digite o valor da chave que deseja inserir na arvore RN: \nou digite 000 para voltar\n");
                do{
                printf ("Chave: ");
                scanf ("%d", &chave);
                printf ("\n");
                if(chave==000)
                    break;
                raiz =  arvRN_insere (raiz, chave);
                printf ("A chave foi inserida com sucesso!\n\n\n");

                }while (chave ==(int)chave);


            break;
            case 2: //Remover
                printf ("Digite o valor da chave que deseja\nremover da arvore RN: ");
                scanf ("%d", &chave);
                aux = arvRN_busca (raiz, chave);
                arvRN_remove (raiz, aux);

                if (aux != nodonull)
                    printf ("\nA chave foi removida com sucesso!\n");
                else
                    printf ("\nEsta chave nao existe.\n");
            break;
            case 3: //Buscar
                printf ("Digite o valor da chave que deseja\nbuscar na arvore RN: ");
                scanf ("%d", &chave);
                aux = arvRN_busca (raiz, chave);

                if (aux == nodonull)
                    printf ("\nChave nao encontrada.\n");

                else
                if(aux != nodonull){
                    printf ("\nchave: ");
                    printf ("%d ", aux->chave);
                    printf ("encontrada\n\n");
                }
            break;
            case 4: //Imprimir

                if (raiz != nodonull) {
                    op = arvRN_menuImprimir ();

                    if (op == 1)
                        arvRN_imprimePreOrdem (raiz);
                    else if (op == 2)
                        arvRN_imprimeEmOrdem (raiz);
                    else if (op == 3)
                        arvRN_imprimePosOrdem (raiz);
                    }
                else
                    printf ("\nA arvore esta vazia.\n");
            break;
            case 5:
                arvRN_destroi (raiz);
                arvRN_destroi (nodonull);
                arvRN_inicializa();

            break;
            default:
            break;
        }
        op = arvRN_menu ();
    }
    arvRN_destroi (raiz);
    arvRN_destroi (nodonull);
}
